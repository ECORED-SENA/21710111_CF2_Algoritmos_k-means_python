function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5WSY6rlMY70":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

